filters Package
===============

:mod:`_base` Module
-------------------

.. automodule:: html5lib.filters._base
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`alphabeticalattributes` Module
------------------------------------

.. automodule:: html5lib.filters.alphabeticalattributes
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`inject_meta_charset` Module
---------------------------------

.. automodule:: html5lib.filters.inject_meta_charset
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`lint` Module
------------------

.. automodule:: html5lib.filters.lint
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`optionaltags` Module
--------------------------

.. automodule:: html5lib.filters.optionaltags
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`sanitizer` Module
-----------------------

.. automodule:: html5lib.filters.sanitizer
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`whitespace` Module
------------------------

.. automodule:: html5lib.filters.whitespace
    :members:
    :undoc-members:
    :show-inheritance:

